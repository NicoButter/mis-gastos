# Gastio — Textos públicos y legales (v0.1)

Borradores editables en Markdown para integrar al repositorio de Gastio. **No publicar sin completar campos `[COMPLETAR]`, `[DEFINIR]` y `[VERIFICAR]`, confirmar controles operativos y obtener revisión jurídica.**

Archivos:

1. `docs/legal/01_terminos_y_condiciones.md`
2. `docs/legal/02_politica_de_privacidad.md`
3. `docs/legal/03_como_funciona.md`
4. `docs/legal/04_seguridad_y_datos.md`
5. `docs/legal/05_checklist_publicacion.md` (interno)

Rutas web sugeridas (Angular públicas): `/terminos`, `/privacidad`, `/como-funciona`, `/seguridad`.

Los textos describen el uso actual del producto según el trabajo reportado: Google OIDC; hogares; cuentas; ingresos, gastos y transferencias; tarjetas y cuotas; cuotas sin tarjeta; recurrencias y dashboard. No se asume conectividad bancaria ni suscripciones comerciales propias activas.

Fuentes oficiales y decisiones por completar: ver checklist. Fecha de preparación: 13 de octubre de 2026.
